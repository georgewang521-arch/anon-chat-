
const socket = io();

// Generate/get persistent token (UUID v4-like) stored in localStorage
function getToken() {
  let t = localStorage.getItem('anon_token');
  if (!t) {
    t = ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
      (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    );
    localStorage.setItem('anon_token', t);
  }
  return t;
}

const $setup = document.getElementById('setup');
const $matching = document.getElementById('matching');
const $chat = document.getElementById('chat');

const $goBtn = document.getElementById('goBtn');
const $retryBtn = document.getElementById('retryBtn');
const $backBtn = document.getElementById('backBtn');
const $sendBtn = document.getElementById('send');
const $leaveBtn = document.getElementById('leave');

const $interests = document.getElementById('interests');
const $gender = document.getElementById('gender');
const $avatar = document.getElementById('avatar');

const $messages = document.getElementById('messages');
const $msgInput = document.getElementById('msg');
const $partner = document.getElementById('partner');

function show(id) {
  [$setup,$matching,$chat].forEach(s=>s.classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
}

$goBtn.addEventListener('click', () => {
  const interests = ($interests.value || '')
    .split(',').map(s=>s.trim()).filter(Boolean).slice(0,20);
  const gender = $gender.value;
  const avatar = ($avatar.value || '').trim() || undefined;
  const token = getToken();

  socket.emit('set_profile_and_find', { token, interests, gender, avatar });
  show('matching');
});

$retryBtn.addEventListener('click', () => socket.emit('try_match_again'));
$backBtn.addEventListener('click', () => show('setup'));

$sendBtn.addEventListener('click', sendMessage);
$msgInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') sendMessage(); });
$leaveBtn.addEventListener('click', () => socket.emit('leave'));

function sendMessage() {
  const text = $msgInput.value.trim();
  if (!text) return;
  socket.emit('message', text);
  $msgInput.value = '';
}

socket.on('matching', () => { show('matching'); });

socket.on('matched', ({ roomId, partner }) => {
  show('chat');
  $messages.innerHTML = '';
  const g = partner.gender ? ` · 性别：${partner.gender}` : '';
  const ints = partner.interests?.length ? ` · 兴趣：${partner.interests.join('、')}` : '';
  $partner.innerHTML = `<div class="partner">${partner.avatar || '🌀'} <b>${partner.anonId}</b>${g}${ints}</div>`;
});

socket.on('message', (msg) => {
  const item = document.createElement('div');
  item.className = 'bubble';
  item.innerHTML = `<span class="avatar">${msg.avatar}</span><div class="content"><div class="meta">${msg.from}</div><div>${escapeHtml(msg.text)}</div></div>`;
  $messages.appendChild(item);
  $messages.scrollTop = $messages.scrollHeight;
});

socket.on('system', (text) => {
  const item = document.createElement('div');
  item.className = 'sys';
  item.textContent = text;
  $messages.appendChild(item);
  $messages.scrollTop = $messages.scrollHeight;
});

function escapeHtml(str) {
  return str.replace(/[&<>"]+/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[s]));
}
