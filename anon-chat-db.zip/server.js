
/*
 * Anonymous Interest Matching Chat — server with PostgreSQL persistence
 */
const express = require('express');
const http = require('http');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const { Server } = require('socket.io');
const { customAlphabet } = require('nanoid');
const { Pool } = require('pg');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(helmet());
app.use(compression());
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;

// ---- PostgreSQL ----
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

async function initDb() {
  await pool.query(`
    create table if not exists users (
      id uuid primary key,
      anon_id text not null,
      gender text default '',
      avatar text default '',
      created_at timestamptz default now()
    );
    create table if not exists interests (
      id serial primary key,
      name text unique not null
    );
    create table if not exists user_interests (
      user_id uuid references users(id) on delete cascade,
      interest_id int references interests(id) on delete cascade,
      primary key (user_id, interest_id)
    );
    create table if not exists matches (
      id uuid primary key,
      user_a uuid references users(id) on delete set null,
      user_b uuid references users(id) on delete set null,
      created_at timestamptz default now(),
      closed_at timestamptz
    );
    create table if not exists messages (
      id bigserial primary key,
      match_id uuid references matches(id) on delete cascade,
      sender uuid references users(id) on delete set null,
      text text not null,
      ts timestamptz default now()
    );
  `);
  console.log("DB ready");
}
initDb().catch(err => {
  console.error("DB init failed", err);
  process.exit(1);
});

// ---- In-memory waiting queue (for fast matching) ----
const waitingQueue = []; // { socketId, userId, profile, joinedAt }
const activeRooms = new Map(); // roomId -> { users: [socketId1, socketId2], userIds: [uuid, uuid] }

const animals = ['tiger','otter','panda','lion','fox','eagle','dolphin','wolf','koala','owl','lynx','whale'];
const adjectives = ['moon','silent','wild','bright','moss','coral','amber','shadow','mint','crystal','ember','dune'];
const nano4 = customAlphabet('0123456789', 4);
function makeAnonId() {
  const a = adjectives[Math.floor(Math.random()*adjectives.length)];
  const b = animals[Math.floor(Math.random()*animals.length)];
  return `${a}-${b}-${nano4()}`;
}

function sanitizeProfile(p) {
  return { anonId: p.anonId, avatar: p.avatar, gender: p.gender || '', interests: p.interests || [] };
}

function matchScore(aInterests, bInterests) {
  const A = new Set((aInterests||[]).map(s=>s.toLowerCase()));
  const B = new Set((bInterests||[]).map(s=>s.toLowerCase()));
  let overlap = 0; for (const x of A) if (B.has(x)) overlap++;
  return overlap;
}

function pickBestMatch(me) {
  let bestIdx = -1, best = -1;
  for (let i=0;i<waitingQueue.length;i++) {
    const cand = waitingQueue[i];
    if (cand.socketId === me.socketId) continue;
    const s = matchScore(me.profile.interests, cand.profile.interests);
    if (s > best) { best = s; bestIdx = i; }
  }
  const waited = Date.now() - me.joinedAt;
  if (bestIdx !== -1 && best > 0) return bestIdx;
  if (waited > 5000 && waitingQueue.length > 1) {
    for (let i=0;i<waitingQueue.length;i++) if (waitingQueue[i].socketId !== me.socketId) return i;
  }
  return -1;
}

async function upsertUser(token, profile) {
  // token is a UUID from client; create if not exists
  const userId = token;
  const { rows } = await pool.query('select id from users where id = $1', [userId]);
  if (rows.length === 0) {
    await pool.query('insert into users (id, anon_id, gender, avatar) values ($1,$2,$3,$4)', [userId, profile.anonId, profile.gender||'', profile.avatar||'']);
  } else {
    await pool.query('update users set anon_id=$2, gender=$3, avatar=$4 where id=$1', [userId, profile.anonId, profile.gender||'', profile.avatar||'']);
  }
  // interests
  const ints = (profile.interests||[]).map(s=>s.toLowerCase());
  await pool.query('delete from user_interests where user_id = $1', [userId]);
  for (const name of ints) {
    const ins = await pool.query('insert into interests (name) values ($1) on conflict (name) do update set name=excluded.name returning id', [name]);
    const iid = ins.rows[0].id;
    await pool.query('insert into user_interests (user_id, interest_id) values ($1,$2) on conflict do nothing', [userId, iid]);
  }
  return userId;
}

async function createMatch(userA, userB) {
  const { v4: uuidv4 } = require('uuid');
  const id = uuidv4();
  await pool.query('insert into matches (id, user_a, user_b) values ($1,$2,$3)', [id, userA, userB]);
  return id;
}

io.on('connection', (socket) => {
  let currentRoom = null;
  let myUserId = null;
  let myProfile = null;

  socket.on('set_profile_and_find', async (payload) => {
    try {
      const token = typeof payload?.token === 'string' ? payload.token : null;
      if (!token) return socket.emit('system', '缺少用户令牌。请刷新页面重试。');

      myProfile = {
        anonId: makeAnonId(),
        avatar: (payload?.avatar||'🌀').slice(0,8),
        gender: (payload?.gender||'').slice(0,16),
        interests: Array.isArray(payload?.interests) ? payload.interests.slice(0,20) : []
      };
      myUserId = token;

      await upsertUser(myUserId, myProfile);

      const me = { socketId: socket.id, userId: myUserId, profile: myProfile, joinedAt: Date.now() };
      waitingQueue.push(me);

      const idx = pickBestMatch(me);
      if (idx !== -1) {
        const other = waitingQueue.splice(idx, 1)[0];
        const myIdx = waitingQueue.findIndex(x => x.socketId === me.socketId);
        if (myIdx !== -1) waitingQueue.splice(myIdx, 1);
        const { v4: uuidv4 } = require('uuid');
        const roomId = uuidv4();
        // persist match
        await createMatch(me.userId, other.userId);

        activeRooms.set(roomId, { users: [me.socketId, other.socketId], userIds: [me.userId, other.userId] });
        [me.socketId, other.socketId].forEach(id => io.sockets.sockets.get(id)?.join(roomId));
        currentRoom = roomId;

        io.to(me.socketId).emit('matched', { roomId, partner: sanitizeProfile(other.profile) });
        io.to(other.socketId).emit('matched', { roomId, partner: sanitizeProfile(me.profile) });
      } else {
        socket.emit('matching');
      }
    } catch (e) {
      console.error(e);
      socket.emit('system', '服务器错误，请稍后再试。');
    }
  });

  socket.on('try_match_again', () => {
    const meIdx = waitingQueue.findIndex(x => x.socketId === socket.id);
    if (meIdx !== -1) {
      const me = waitingQueue[meIdx];
      const idx = pickBestMatch(me);
      if (idx !== -1) {
        const other = waitingQueue.splice(idx, 1)[0];
        waitingQueue.splice(meIdx, 1);

        const { v4: uuidv4 } = require('uuid');
        const roomId = uuidv4();
        createMatch(me.userId, other.userId).catch(()=>{});

        activeRooms.set(roomId, { users: [me.socketId, other.socketId], userIds: [me.userId, other.userId] });
        [me.socketId, other.socketId].forEach(id => io.sockets.sockets.get(id)?.join(roomId));
        currentRoom = roomId;

        io.to(me.socketId).emit('matched', { roomId, partner: sanitizeProfile(other.profile) });
        io.to(other.socketId).emit('matched', { roomId, partner: sanitizeProfile(me.profile) });
      }
    }
  });

  socket.on('message', async (text) => {
    if (!currentRoom || typeof text !== 'string') return;
    const trimmed = text.trim().slice(0, 1000);
    if (!trimmed) return;
    io.to(currentRoom).emit('message', {
      from: myProfile?.anonId || 'anon',
      avatar: myProfile?.avatar || '🌀',
      text: trimmed,
      ts: Date.now()
    });
    // persist message (best-effort)
    try {
      // find match containing these two userIds created most recently
      const room = activeRooms.get(currentRoom);
      if (room) {
        // We don't store roomId in DB; messages link to the latest open match between the two users
        const { rows } = await pool.query(`
          select id from matches
          where (user_a = $1 and user_b = $2) or (user_a = $2 and user_b = $1)
          order by created_at desc
          limit 1`, [room.userIds[0], room.userIds[1]]);
        if (rows.length) {
          await pool.query('insert into messages (match_id, sender, text) values ($1,$2,$3)', [rows[0].id, myUserId, trimmed]);
        }
      }
    } catch (e) {
      console.error("persist message failed", e);
    }
  });

  socket.on('leave', () => {
    if (currentRoom) {
      io.to(currentRoom).emit('system', '对方已离开，正在为你重新匹配…');
      activeRooms.delete(currentRoom);
      for (const id of io.sockets.adapter.rooms.get(currentRoom) || []) {
        io.sockets.sockets.get(id)?.leave(currentRoom);
      }
      currentRoom = null;
    }
    const me = waitingQueue.findIndex(x => x.socketId === socket.id);
    if (me === -1 && myProfile && myUserId) {
      waitingQueue.push({ socketId: socket.id, userId: myUserId, profile: myProfile, joinedAt: Date.now() });
      socket.emit('matching');
    }
  });

  socket.on('disconnect', () => {
    const i = waitingQueue.findIndex(x => x.socketId === socket.id);
    if (i !== -1) waitingQueue.splice(i, 1);
    if (currentRoom) {
      io.to(currentRoom).emit('system', '对方已断开连接。');
      activeRooms.delete(currentRoom);
    }
  });
});

// Optional minimal history API for a client token
app.get('/api/my/history', async (req, res) => {
  const token = req.query.token;
  if (!token) return res.status(400).json({ error: 'missing token'});
  const { rows } = await pool.query(`
    select m.id as match_id, m.created_at,
           (case when m.user_a = $1 then m.user_b else m.user_a end) as partner_id,
           (select array_agg(row_to_json(x)) from (
              select sender, text, ts from messages where match_id = m.id order by ts asc limit 50
           ) x) as messages
    from matches m
    where m.user_a = $1 or m.user_b = $1
    order by m.created_at desc
    limit 10
  `, [token]);
  res.json(rows);
});

server.listen(PORT, () => {
  console.log(`Server listening on :${PORT}`);
});
